CHAPCHITRA C05 — ICON 04 / ONTO WHAT YOU WEAR
Creative approved by owner: 2026-11-13
Preserved GitHub source branch: feature/chapchitra-c05-icon04-soft-bounce-20261113
No website integration or deployment performed.

PRIMARY DELIVERABLES
- CHAPCHITRA_C05_Icon04_Onto_What_You_Wear_V3_SOFT_BOUNCE.lottie (native dotLottie)
- CHAPCHITRA_C05_Icon04_Onto_What_You_Wear_V3_SOFT_BOUNCE.json (editable Bodymovin)
- ICON04_V3_SOFT_BOUNCE_KEYFRAME_PREVIEW.gif (corrected preview: white shirts / original green)
- ICON04_V3_LOCAL_REVIEW.html + lottie.min.js (standalone offline native player)

SOURCES & REPRODUCTION
- V2 baseline JSON (preserved)
- refine_icon04_soft_bounce.py (rebuild V3 from V2 JSON)
- produce_icon04_drop_in_V2_ORIGINAL.py (historical original-SVG generator, original SVG required)
- capture_icon04.py (local Chromium/WebM capture; Playwright must be installed)
- LOTTIE_WEB_LICENSE.md (Lottie-web MIT licence)
- README.md (usage/QA)

IMPORTANT: The original owner-authored SVG file is NOT present in the source repository folder.
It is not falsely represented as bundled. The native vector Lottie JSON provides editable vector shapes,
and refine_icon04_soft_bounce.py is runnable against the bundled V2 JSON.

Native playback: open ICON04_V3_LOCAL_REVIEW.html with bundled lottie.min.js beside it.
The original V3 JSON, bounce timing and all shirt geometry are unchanged.
